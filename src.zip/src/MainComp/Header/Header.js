import React, { Component, MainComp } from 'react'; 
import "./Header.css"; 
import headerimage from "../../img/headerImag.jpeg"; 


const click =(e)=> {
  e.preventDefault();
  console.log(e);
}

export class Header extends Component {

    render() {
        console.log (this.props);
        
        return (

          <>
            {/* Navigation button */}
            <header> 
                <h1>e-Trade</h1>

                <nav className = "navBar">
                    <input type = "search" className = "search" placeholder = "search for anything"/>
                    <button type = "button" className = "login" onClick = {click} > Log in </button>
                    <button type = "button" className = "cart" onClick = {click} > Cart </button>
                </nav>


            </header>

            <p>*Header image is supposed to be here, but I'll figure this out later*sorry</p>

            <headercontainer>
              <img className="headerimage" src = {headerimage} alt="headerimage"/>
            </headercontainer>
          </>

        ); 
    }
}

export default Header; 
