import React, { Component, MainComp } from 'react'; 
import './App.css'; 
import Mainpage from "./MainComp/MainPage/Mainpage"; 
import Header from "./MainComp/Header/Header"; 
import Side from "./MainComp/Sidebar/Sidebar"; 
import PopularProduct from "./MainComp/PopularProduct/PopularProduct"; 
import Categories from "./MainComp/Categories/Categories"; 
import Footer from "./MainComp/Footer/Footer";  
//import headerimage from './headerImag.jpeg'; 

class App extends Component {
  //fetch  API
  //state = {
    //will add this later

  //};  

  //fetch API
  // componentDidMount() {
  //   fetch("....")
  //     .then (res  => {
  //       if (res.status !== 200) {
  //         console.log(`This is a error ${res.status}`); 
  //       }
  //       res.json()
  //         .then(data => {
  //           this.setState({
  //             //will add this later
  //           }); 
  //         }); 
  //     }); 
  // }


  /* Header.js control */
  //Search Method//
  render () {
  
    return(
      <>
      {/*Header.js */}
      <Header 
     
      />
      {/*Main.js*/}
      <Mainpage 
          
      />
      </>
    ); 
  }
  
}


export default App;
